/**
 *
 * @author 19101268
 */
public class Main
{
    public static void main(String[] args) 
    {
        Book b1 = new Book();
        b1.setTitle("Developing Java Software");
        b1.setAuthor("Russel Winderland");
        b1.setPrice(79.75);
        
        System.out.println(b1.toString());
        
        
    }
    
}
