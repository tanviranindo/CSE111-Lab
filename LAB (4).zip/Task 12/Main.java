/**
 *
 * @author 19101268
 */
public class Main {
    public static void main (String[] args) {
        Author author = new Author("Tanvir", "Anindo");
        System.out.println(author);
    }
}