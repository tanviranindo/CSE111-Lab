/**
 *
 * @author 19101268
 */
public class Course {
  String course;
  
  Course(String c) {
    course = c;
  }
  
}
