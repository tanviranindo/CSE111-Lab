/**
 *
 * @author 19101268
 */
public class Student {
    public String name;
    public int id;
    
    Student(String n, int i) {
        name = n;
        id += i; 
    }
}